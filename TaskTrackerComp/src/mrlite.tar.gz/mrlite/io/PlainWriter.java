package mrlite.io;

public class PlainWriter extends Writer{

}
